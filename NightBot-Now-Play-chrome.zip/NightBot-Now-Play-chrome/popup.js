const body = document.getElementById("body");
const portNumberInput = document.getElementById("port-number");
const textFormatInput = document.getElementById("text-format");
const checkBtn = document.getElementById("check-btn");

portNumberInput.addEventListener("keyup", function (event) {
  let tmp = parseInt(this.value.replace(/[^-0-9]/g, "")) || 0;
  this.value = String(tmp > 65535 ? 65535 : tmp);
});
checkBtn.addEventListener("click", function (event) {
  chrome.storage.sync.set({ portNumber: portNumberInput.value }, null);
  chrome.storage.sync.set({ textFormat: textFormatInput.value }, null);
  const ele = document.createElement("div");
  ele.id = "alert";
  ele.innerText = "설정값이 저장되었습니다.";
  body.appendChild(ele);
  setTimeout(function () {
    document.getElementById("alert").remove();
  }, 3100);
  chrome.runtime.sendMessage({ debug: [1, "Edited environment settings."] });
});

document.addEventListener("DOMContentLoaded", function (event) {
  chrome.storage.sync.get(["portNumber"], function (result) {
    if (result.portNumber === undefined) {
      chrome.storage.sync.set({ portNumber: "3000" }, null);
      portNumberInput.value = "3000";
    } else {
      portNumberInput.value = String(result.portNumber);
    }
  });
  chrome.storage.sync.get(["textFormat"], function (result) {
    if (result.textFormat === undefined) {
      chrome.storage.sync.set({ textFormat: "[$title] - [$artist]" }, null);
      textFormatInput.value = String("[$title] - [$artist]");
    } else {
      textFormatInput.value = String(result.textFormat);
    }
  });
});
