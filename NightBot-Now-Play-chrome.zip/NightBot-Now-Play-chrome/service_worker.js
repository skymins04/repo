// service_worker.js

function onNightBotAutoDJ() {
  let oldCurrentMusic = "";
  let oldQueue = [];
  let currentMusicFlag2 = true;
  let queueFlag = true;
  chrome.runtime.sendMessage({ debug: [0, "Activated Worker."] });

  setInterval(() => {
    const currentMusicFlag1 = document.querySelector(
      ".current-track > h4 > strong.ng-binding > span"
    );
    const currentMusic = document.querySelector(
      ".current-track > h4 > strong.ng-binding"
    ).innerText;

    if (currentMusicFlag1 != null && currentMusic.split("—")[0].trim() != "") {
      if (oldCurrentMusic != currentMusic) {
        currentMusicFlag2 = true;
        oldCurrentMusic = currentMusic;
        const time = document
          .querySelector(".current-track > p:nth-of-type(1)")
          .innerText.trim();
        const artist = document
          .querySelector(".current-track > p:nth-of-type(3)")
          .innerText.trim();
        console.log("send cm");
        chrome.runtime.sendMessage({
          currentMusic: [
            currentMusic.split("—")[0].trim(),
            currentMusic.split("—")[1].trim(),
            artist,
            time,
          ],
        });
      }
    } else if (currentMusicFlag2) {
      console.log("send cm");
      currentMusicFlag2 = false;
      oldCurrentMusic = "";
      chrome.runtime.sendMessage({ currentMusic: ["", "", "", ""] });
    }

    const queue = [];
    document.querySelectorAll(".table tbody tr").forEach((ele, idx) => {
      queue.push([
        ele.querySelector("td:nth-child(2)").innerText,
        ele.querySelector("td:nth-child(3)").innerText,
        ele.querySelector("td:nth-child(4)").innerText,
        ele.querySelector("td:nth-child(5)").innerText,
      ]);
    });

    if (queue.length != 0) {
      if (JSON.stringify(oldQueue) !== JSON.stringify(queue)) {
        queueFlag = true;
        oldQueue = queue;
        console.log("send q");
        chrome.runtime.sendMessage({
          queue: queue,
        });
      }
    } else if (queueFlag) {
      queueFlag = false;
      oldQueue = [];
      console.log("send q");
      chrome.runtime.sendMessage({
        queue: oldQueue,
      });
    }
  }, 10);
}

let portNumber;
let textFormat;

function getEnvironment() {
  chrome.storage.sync.get(["portNumber"], function (result) {
    if (result.portNumber === undefined) {
      chrome.storage.sync.set({ portNumber: "3000" }, null);
      portNumber = "3000";
    } else {
      portNumber = result.portNumber;
    }
  });
  chrome.storage.sync.get(["textFormat"], function (result) {
    if (result.textFormat === undefined) {
      chrome.storage.sync.set({ textFormat: "[$title] - [$artist]" }, null);
      textFormat = "[$title] - [$artist]";
    } else {
      textFormat = result.textFormat;
    }
  });
}

chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
  if (
    changeInfo.status == "complete" &&
    tab.url == "https://nightbot.tv/song_requests"
  ) {
    getEnvironment();
    chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      func: onNightBotAutoDJ,
    });
  }
});

let lstQueue = [];
let lstCurrentMusic = [];
chrome.runtime.onMessage.addListener(async (request, sender, sendResponse) => {
  if (request.currentMusic !== undefined) {
    console.log(
      "Current music : ",
      JSON.stringify({ data: request.currentMusic, format: textFormat })
    );
    lstCurrentMusic = request.currentMusic;
    await fetch(`http://localhost:${portNumber}/currentMusic`, {
      method: "POST",
      mode: "cors",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ data: request.currentMusic, format: textFormat }),
    });
  }
  if (request.queue !== undefined) {
    console.log(
      "Queue : ",
      JSON.stringify({ data: request.queue, format: textFormat })
    );
    lstQueue = request.queue;
    await fetch(`http://localhost:${portNumber}/queue`, {
      method: "POST",
      mode: "cors",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ data: request.queue, format: textFormat }),
    });
  }
  if (request.debug !== undefined) {
    if (request.debug[0] == 1) {
      getEnvironment();
      setTimeout(async () => {
        await fetch(`http://localhost:${portNumber}/currentMusic`, {
          method: "POST",
          mode: "cors",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            data: lstCurrentMusic,
            format: textFormat,
          }),
        });
        await fetch(`http://localhost:${portNumber}/queue`, {
          method: "POST",
          mode: "cors",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ data: lstQueue, format: textFormat }),
        });
      }, 100);
    }
    console.log("Debug : ", request.debug);
  }
});
